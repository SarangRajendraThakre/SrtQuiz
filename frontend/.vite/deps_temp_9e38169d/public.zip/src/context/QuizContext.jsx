import React, { createContext, useState, useContext, useEffect } from "react";
import axios from 'axios';

// Create a context to hold the state
const QuizContext = createContext();

// Create a provider component to manage the state
export const QuizContextProvider = ({ children }) => {
  const [quizData, setQuizData] = useState({ quiz: null, questions: [] }); // Initialize quizData with an empty questions array
  const [questionType, setQuestionType] = useState(null);
  const [questionIdd, setQuestionIdd] = useState(null);
  const [createdQuizId, setCreatedQuizId] = useState(null); // State to hold the createdQuizId

  const updateQuestionType = (type) => {
    setQuestionType(type);
  };
  const updateQuestionIdd = (id) => {
    setQuestionIdd(id);
  };

  // Define fetchQuizData function
  const fetchQuizData = async () => {
    try {
      const quizId = localStorage.getItem('createdQuizId');
      console.log('Quiz ID:', quizId);

      if (!quizId) {
        throw new Error('Quiz ID not found in local storage');
      }

      // Fetch the quiz data from the backend
      const response = await axios.get(`http://localhost:5000/api/quizzes/quiz/${quizId}`);
      console.log('Response:', response);

      // Set the quiz data state with the fetched data
      setQuizData(response.data.quiz);
    } catch (error) {
      console.error('Error fetching quiz:', error);
    }
  };

  useEffect(() => {
    // Fetch quiz data when component mounts
    fetchQuizData();
  }, [createdQuizId]); // Add createdQuizId to the dependency array

  const addQuestion = async (newQuestionData) => {
    try {
      // Send the new question data to the backend
      const response = await axios.post("http://localhost:5000/api/add-question", newQuestionData);

      // Log the response from the backend
      console.log("Question added successfully:", response.data);

      if (response.data.questions && response.data.questions.length > 0) {
        const questionId = response.data.questions[response.data.questions.length - 1]._id;
        // Proceed with further operations using questionId
        setQuestionIdd(questionId);
      } else {
        console.error("Error: No questions found in the response data.");
        // Handle the case where no questions are found in the response data
      }

      // Update the quizData state with the new question
      setQuizData(prevQuizData => ({
        ...prevQuizData,
        questions: [...prevQuizData.questions, response.data.quiz.questions[response.data.quiz.questions.length - 1]]
      }));
      
      console.log(quizData);
    } catch (error) {
      console.error("Error adding question:", error);
      // Handle error
    }
  };

  const deleteQuestionById = async (questionId) => {
    try {
      // Send a request to delete the question from the backend
      await axios.delete(`http://localhost:5000/api/questions/delete/${questionId}`);
      console.log('Question deleted successfully');
      // Refetch the quiz data
      await fetchQuizData();
    } catch (error) {
      console.error('Error deleting question:', error);
      // Handle error
    }
  };

  // Function to get question data by ID
  const getQuestionById = () => {
    if (!quizData || !quizData.questions || !questionIdd) {
      // Return null if quizData, questions array, or questionIdd is not available
      return null;
    }

    // Find the question in the questions array by its ID
    const foundQuestion = quizData.questions.find(question => question._id === questionIdd);

    // Return the found question or null if not found
    return foundQuestion || null;
  };


  const updateQuestionById = async (questionId, updatedQuestionData) => {
    try {
      // Send the updated question data to the backend
      const response = await axios.put(`http://localhost:5000/api/questions/update/${questionId}`, updatedQuestionData);
  
      // Log the response from the backend
      console.log("Question updated successfully:", response.data);
  
      // Refetch the quiz data to get the updated question
      await fetchQuizData();
    } catch (error) {
      console.error("Error updating question:", error);
      // Handle error
    }
  };

  // Provide the state and functions to the context
  return (
    <QuizContext.Provider value={{ quizData, addQuestion, questionType, questionIdd, updateQuestionIdd, updateQuestionType, deleteQuestionById, fetchQuizData, getQuestionById, updateQuestionById }}>
      {children}
    </QuizContext.Provider>
  );
};

// Custom hook to consume the context in functional components
export const useQuiz = () => useContext(QuizContext);
